# vrbll Backend

TypeScript/Node.js WebSocket + WebRTC chat/voice backend for Akira OS.

## Features
- WebSocket chat
- WebRTC voice
- GateScore auth

## Dev
`npm install && npm run dev`

## Test
Test stubs in `tests/`.
