# VRBLL Demo Instructions

## Quick Start

1. **Build and Run VRBLL (Chat & Voice):**
   ```sh
   cd /Users/dwido/AKIRA-OS/apps/vrbll
   # If using Docker:
   docker build -t vrbll . && docker run -it --rm -p 3000:3000 vrbll
   # Or, for Node.js/TypeScript:
   npm install && npm run start
   ```

2. **Build and Run AI (ChatGPT Integration):**
   ```sh
   cd /Users/dwido/AKIRA-OS/apps/ai
   npm install && npm run start
   # Or, for Python:
   python3 ai_worker.py
   ```

3. **Configuration:**
   - Place your OpenAI API key in `apps/ai/config.json`:
     ```json
     { "openai_api_key": "sk-..." }
     ```
   - For local/server fallback, see `ai_worker.py` or `aiServer.ts`.

4. **Cross-Device/Server:**
   - Use Docker Compose or run the above commands on each device (Akira OS, your fiancée’s PC, server).

---

## Features
- Chat, voice, mesh, E2E, moderation, bots, theming, monetization, privacy, multi-identity, protocol bridges.
- All features are modular and testable.

---

## Pitch-Ready
- Demo chat and voice in browser or terminal.
- Show AI (ChatGPT) responses in chat.
- All code is local-first, private, and ready for extension.

---

For help, see each module’s README or ask Copilot/ChatGPT in your Akira OS!
