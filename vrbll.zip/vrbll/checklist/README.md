# DayDreamers Checklist System

A collaborative checklist/task system for the DayDreamers team, integrated with the AI Worker automation system.

- Add, view, and approve tasks in the VRBLL UI
- AI Worker monitors and processes tasks
- Results and approvals are tracked and auditable

See backend API and UI components for usage.
