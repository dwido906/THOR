// VRBLL Minimal Terminal UI (C)
#include <stdio.h>
int main() {
    printf("[VRBLL] CLI UI starting...\n");n    // TODO: Connect, join channel, send/receive messages, voice
    return 0;
}
