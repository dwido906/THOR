// VRBLL GateScore Auth Integration (C)
#ifndef VRBLL_GATESCORE_AUTH_H
#define VRBLL_GATESCORE_AUTH_H
int gatescore_auth(const char* user, const char* token);
#endif
