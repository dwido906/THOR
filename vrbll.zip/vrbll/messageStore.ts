// VRBLL Message Store
// Persistent message storage using Akira OS IPC (stub)

export interface ChatMessage {
  id: string;
  from: string;
  content: string;
  timestamp: number;
}

const messages: ChatMessage[] = [];

export function storeMessage(msg: ChatMessage) {
  // TODO: Replace with Akira OS IPC to core/db
  messages.push(msg);
}

export function getMessages(): ChatMessage[] {
  return messages;
}
