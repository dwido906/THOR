# VRBLL Monetization

This module provides in-app purchases, tipping, and premium feature management for VRBLL. It is modular, privacy-respecting, and testable.

## Features
- In-app purchases (IAP)
- Tipping and microtransactions
- Premium feature access control
- Modular, containerized, and testable

## Integration
- TypeScript APIs for VRBLL UI and backend
- Works with Akira mesh and GateScore authentication

## Development
- See `monetizationApi.ts` for API details
- Run `test_monetizationApi.ts` for test stubs

---
