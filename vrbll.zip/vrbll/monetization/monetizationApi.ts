// monetizationApi.ts
// TypeScript API for monetization in VRBLL

export type Purchase = {
  id: string;
  amount: number;
  type: 'iap' | 'tip' | 'premium';
  status: 'pending' | 'completed' | 'failed';
};

import * as store from './monetizationStore';

export function makePurchase(type: 'iap' | 'tip' | 'premium', amount: number): Promise<Purchase> {
  return store.makePurchase(type, amount);
}

export function getPurchases(): Promise<Purchase[]> {
  return store.getPurchases();
}

export function checkPremiumAccess(): Promise<boolean> {
  return store.checkPremiumAccess();
}
