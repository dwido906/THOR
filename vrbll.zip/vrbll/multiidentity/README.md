# VRBLL Multi-Identity/Persona Support

This module provides support for multiple user identities and personas in VRBLL, including switching, isolation, and presence management.

## Features
- Multiple identities/personas per user
- Fast switching and isolation
- Presence and status per identity
- Modular, containerized, and testable

## Integration
- C and TypeScript APIs for VRBLL core and UI
- Works with Akira mesh and GateScore authentication

## Development
- See `multiidentity_api.h` and `multiidentityApi.ts` for API details
- Run `test_multiidentity.c` and `test_multiidentityApi.ts` for test stubs

---
