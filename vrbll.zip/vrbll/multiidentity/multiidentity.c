// multiidentity.c
// Minimal multi-identity/persona support implementation for VRBLL (C)
#include "multiidentity_api.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define IDENTITY_FILE_PREFIX "vrbll_identity_"

int multiidentity_init(void) {
    // No-op for demo
    return 0;
}

int multiidentity_add(const char* user, const char* identity) {
    char filename[256];
    snprintf(filename, sizeof(filename), "%s%s.txt", IDENTITY_FILE_PREFIX, user);
    FILE* f = fopen(filename, "a");
    if (!f) return -1;
    fprintf(f, "%s\n", identity);
    fclose(f);
    return 0;
}

int multiidentity_switch(const char* user, const char* identity) {
    char filename[256];
    snprintf(filename, sizeof(filename), "%s%s.active", IDENTITY_FILE_PREFIX, user);
    FILE* f = fopen(filename, "w");
    if (!f) return -1;
    fprintf(f, "%s\n", identity);
    fclose(f);
    return 0;
}

int multiidentity_get(const char* user, char* identity, size_t bufsize) {
    char filename[256];
    snprintf(filename, sizeof(filename), "%s%s.active", IDENTITY_FILE_PREFIX, user);
    FILE* f = fopen(filename, "r");
    if (!f) return -1;
    if (fgets(identity, bufsize, f)) {
        size_t len = strlen(identity);
        if (len > 0 && identity[len-1] == '\n') identity[len-1] = '\0';
        fclose(f);
        return 0;
    }
    fclose(f);
    return -1;
}
