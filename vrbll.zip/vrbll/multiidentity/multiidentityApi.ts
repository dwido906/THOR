// multiidentityApi.ts
// TypeScript API for multi-identity/persona support in VRBLL

import * as store from './multiidentityStore';

export function initMultiIdentity(): Promise<void> {
  return store.initMultiIdentity();
}

export function addIdentity(user: string, identity: string): Promise<void> {
  return store.addIdentity(user, identity);
}

export function switchIdentity(user: string, identity: string): Promise<void> {
  return store.switchIdentity(user, identity);
}

export function getCurrentIdentity(user: string): Promise<string> {
  return store.getCurrentIdentity(user);
}
