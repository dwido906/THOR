// multiidentityStore.ts
// Minimal multi-identity/persona support implementation for VRBLL (TypeScript)
import * as fs from 'fs';

const DB_FILE = 'vrbll_identities.json';

let identities: Record<string, string[]> = {};
let active: Record<string, string> = {};

function loadIdentities() {
  if (fs.existsSync(DB_FILE)) {
    const data = JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
    identities = data.identities || {};
    active = data.active || {};
  } else {
    identities = {};
    active = {};
  }
}

function saveIdentities() {
  fs.writeFileSync(DB_FILE, JSON.stringify({ identities, active }, null, 2));
}

export async function initMultiIdentity() {
  loadIdentities();
}

export async function addIdentity(user: string, identity: string) {
  if (!identities[user]) identities[user] = [];
  if (!identities[user].includes(identity)) identities[user].push(identity);
  saveIdentities();
}

export async function switchIdentity(user: string, identity: string) {
  if (!identities[user]) identities[user] = [];
  if (!identities[user].includes(identity)) identities[user].push(identity);
  active[user] = identity;
  saveIdentities();
}

export async function getCurrentIdentity(user: string): Promise<string> {
  loadIdentities();
  return active[user] || '';
}
