// multiidentity_api.h
// Multi-identity/persona support API for VRBLL (C)
#ifndef MULTIIDENTITY_API_H
#define MULTIIDENTITY_API_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// Initialize multi-identity module
int multiidentity_init(void);

// Add a new identity
int multiidentity_add(const char* user, const char* identity);

// Switch active identity
int multiidentity_switch(const char* user, const char* identity);

// Get current identity
int multiidentity_get(const char* user, char* identity, size_t bufsize);

#ifdef __cplusplus
}
#endif

#endif // MULTIIDENTITY_API_H
