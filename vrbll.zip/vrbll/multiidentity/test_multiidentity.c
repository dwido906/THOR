// test_multiidentity.c
// Test stub for VRBLL multi-identity C API
#include "multiidentity_api.h"
#include <stdio.h>

int main() {
    multiidentity_init();
    multiidentity_add("alice", "work");
    multiidentity_switch("alice", "work");
    char identity[64];
    multiidentity_get("alice", identity, sizeof(identity));
    printf("Multi-identity tests ran (stub)\n");
    return 0;
}
