// test_multiidentityApi.ts
// Test stub for VRBLL multi-identity TypeScript API
import { initMultiIdentity, addIdentity, switchIdentity, getCurrentIdentity } from './multiidentityApi';

describe('multiidentityApi', () => {
  it('should initialize multi-identity', async () => {
    await initMultiIdentity();
  });
  it('should add, switch, and get identity', async () => {
    await addIdentity('alice', 'work');
    await switchIdentity('alice', 'work');
    const identity = await getCurrentIdentity('alice');
    expect(typeof identity).toBe('string');
  });
});
