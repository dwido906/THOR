import React, { useEffect, useState } from 'react';
import axios from 'axios';

export function PresenceDisplay({ userId }: { userId: string }) {
  const [presence, setPresence] = useState<any[]>([]);
  useEffect(() => {
    async function fetchPresence() {
      const res = await axios.get(`/presence/${userId}`);
      setPresence(res.data);
    }
    fetchPresence();
    const interval: any = setInterval(fetchPresence, 5000);
    return () => clearInterval(interval);
  }, [userId]);
  return (
    <div>
      <h4>Presence</h4>
      <ul>
        {presence.map((p, i) => (
          <li key={i}>
            Device: {p.deviceId} — {p.online ? 'Online' : 'Offline'} {p.typing && '(Typing...)'}
          </li>
        ))}
      </ul>
    </div>
  );
}
