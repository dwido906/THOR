// VRBLL Presence and Sync Service (Node.js/TypeScript)
import express from 'express';
import http from 'http';
import WebSocket, { Server as WebSocketServer } from 'ws';

interface Presence {
  userId: string;
  deviceId: string;
  online: boolean;
  lastSeen: number;
  typing: boolean;
  hidePresence?: boolean;
}

let presenceMap: Record<string, Presence> = {};
let readStatus: Record<string, Record<string, number>> = {}; // userId -> msgId -> timestamp

const app = express();
app.use(express.json());

// REST API
app.get('/presence/:userId', (req, res) => {
  const { userId } = req.params;
  const userPresence = Object.values(presenceMap).filter(p => p.userId === userId && !p.hidePresence);
  res.json(userPresence);
});

app.post('/presence/update', (req, res) => {
  const { userId, deviceId, online, typing, hidePresence } = req.body;
  presenceMap[`${userId}:${deviceId}`] = {
    userId, deviceId, online, typing: !!typing, lastSeen: Date.now(), hidePresence: !!hidePresence
  };
  res.json({ success: true });
});

app.post('/read-status', (req, res) => {
  const { userId, msgId } = req.body;
  if (!readStatus[userId]) readStatus[userId] = {};
  readStatus[userId][msgId] = Date.now();
  res.json({ success: true });
});


// WebSocket API
const server = http.createServer(app);
const wss = new WebSocketServer({ server });
wss.on('connection', ws => {
  ws.on('message', msg => {
    try {
      const data = JSON.parse(msg.toString());
      if (data.type === 'presence') {
        presenceMap[`${data.userId}:${data.deviceId}`] = {
          userId: data.userId, deviceId: data.deviceId, online: data.online, typing: !!data.typing, lastSeen: Date.now(), hidePresence: !!data.hidePresence
        };
        ws.send(JSON.stringify({ type: 'presence-ack', userId: data.userId, deviceId: data.deviceId }));
      } else if (data.type === 'typing') {
        if (presenceMap[`${data.userId}:${data.deviceId}`]) {
          presenceMap[`${data.userId}:${data.deviceId}`].typing = !!data.typing;
        }
      } else if (data.type === 'read-status') {
        if (!readStatus[data.userId]) readStatus[data.userId] = {};
        readStatus[data.userId][data.msgId] = Date.now();
      }
      // Broadcast updated presence to all
      wss.clients.forEach(client => {
        if (client !== ws && client.readyState === 1) {
          client.send(JSON.stringify({ type: 'presence-update', presence: Object.values(presenceMap) }));
        }
      });
    } catch {}
  });
});


const PORT = process.env.PRESENCE_PORT || 4102;
server.listen(PORT, () => {
  console.log(`Presence service running on port ${PORT}`);
});

const server = http.createServer(app);
const wss = new WebSocketServer({ server });
wss.on('connection', (ws: WebSocket) => {
  ws.on('message', (msg: any) => {
    try {
      const data = JSON.parse(msg.toString());
      if (data.type === 'presence') {
        presenceMap[`${data.userId}:${data.deviceId}`] = {
          userId: data.userId, deviceId: data.deviceId, online: data.online, typing: !!data.typing, lastSeen: Date.now(), hidePresence: !!data.hidePresence
        };
        ws.send(JSON.stringify({ type: 'presence-ack', userId: data.userId, deviceId: data.deviceId }));
      } else if (data.type === 'typing') {
        if (presenceMap[`${data.userId}:${data.deviceId}`]) {
          presenceMap[`${data.userId}:${data.deviceId}`].typing = !!data.typing;
        }
      } else if (data.type === 'read-status') {
        if (!readStatus[data.userId]) readStatus[data.userId] = {};
        readStatus[data.userId][data.msgId] = Date.now();
      }
      // Broadcast updated presence to all
      wss.clients.forEach((client: any) => {
        if (client !== ws && client.readyState === 1) {
          client.send(JSON.stringify({ type: 'presence-update', presence: Object.values(presenceMap) }));
        }
      });
    } catch {}
  });
});

const PORT = process.env.PRESENCE_PORT || 4102;
server.listen(PORT, () => {
  console.log(`Presence service running on port ${PORT}`);
});
