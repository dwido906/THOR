import request from 'supertest';
import express from 'express';
import presenceService from './presenceService';

describe('Presence Service', () => {
  const app = express();
  app.use(express.json());
  app.use(presenceService);
  it('updates and fetches presence', async () => {
    await request(app).post('/presence/update').send({ userId: 'u1', deviceId: 'd1', online: true });
    const res = await request(app).get('/presence/u1');
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body[0].userId).toBe('u1');
  });
});
