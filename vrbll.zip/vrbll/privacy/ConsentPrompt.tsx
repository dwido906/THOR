import React, { useState } from 'react';
import axios from 'axios';
import { ConsentType } from './consentPolicy';

export function ConsentPrompt({ userId, consentType, onChange }: { userId: string, consentType: ConsentType, onChange: (granted: boolean) => void }) {
  const [granted, setGranted] = useState<boolean|null>(null);
  const handleGrant = async () => {
    await axios.post('/privacy/consent/grant', { userId, consentType });
    setGranted(true);
    onChange(true);
  };
  const handleRevoke = async () => {
    await axios.post('/privacy/consent/revoke', { userId, consentType });
    setGranted(false);
    onChange(false);
  };
  return (
    <div>
      <p>Allow {consentType}?</p>
      <button onClick={handleGrant} disabled={granted===true}>Grant</button>
      <button onClick={handleRevoke} disabled={granted===false}>Revoke</button>
    </div>
  );
}
