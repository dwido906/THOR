# VRBLL Privacy & Consent Management

This module provides user privacy controls, consent management, and audit logging for VRBLL. It is modular, compliant, and testable.

## Features
- User privacy settings and controls
- Consent management and logging
- Audit logs for sensitive actions
- Modular, containerized, and testable

## Integration
- C and TypeScript APIs for VRBLL core and UI
- Works with Akira mesh and GateScore authentication

## Development
- See `privacy_api.h` and `privacyApi.ts` for API details
- Run `test_privacy.c` and `test_privacyApi.ts` for test stubs

---
