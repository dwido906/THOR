// Data anonymization and encryption
import crypto from 'crypto';
export function anonymize(data: string): string {
  return crypto.createHash('sha256').update(data).digest('hex');
}
export function encrypt(data: string, key: string): string {
  const iv = Buffer.alloc(16, 0); // static IV for demo, use random in prod
  const cipher = crypto.createCipheriv('aes-256-ctr', Buffer.from(crypto.createHash('sha256').update(key).digest()), iv);
  let enc = cipher.update(data, 'utf8', 'hex');
  enc += cipher.final('hex');
  return enc;
}
export function decrypt(enc: string, key: string): string {
  const iv = Buffer.alloc(16, 0);
  const decipher = crypto.createDecipheriv('aes-256-ctr', Buffer.from(crypto.createHash('sha256').update(key).digest()), iv);
  let dec = decipher.update(enc, 'hex', 'utf8');
  dec += decipher.final('utf8');
  return dec;
}
