// Consent management API (Node.js/Express)
import express from 'express';
import { ConsentRecord, ConsentType } from './consentPolicy';
import { auditConsent } from './privacyAudit';
const router = express.Router();
let consentRecords: ConsentRecord[] = [];

// Grant consent
router.post('/consent/grant', (req, res) => {
  const { userId, consentType } = req.body;
  if (!userId || !consentType) return res.status(400).json({ error: 'Missing fields' });
  const record: ConsentRecord = { userId, consentType, granted: true, timestamp: Date.now() };
  consentRecords.push(record);
  auditConsent('grant', record);
  res.json({ success: true });
});

// Revoke consent
router.post('/consent/revoke', (req, res) => {
  const { userId, consentType } = req.body;
  const record = consentRecords.find(r => r.userId === userId && r.consentType === consentType && r.granted);
  if (!record) return res.status(404).json({ error: 'Consent not found' });
  record.granted = false;
  record.revokedAt = Date.now();
  auditConsent('revoke', record);
  res.json({ success: true });
});

// List consents
router.get('/consent/list/:userId', (req, res) => {
  const userId = req.params.userId;
  res.json(consentRecords.filter(r => r.userId === userId));
});

export default router;
