// Data classification and access control policies
export type DataClass = 'public' | 'internal' | 'sensitive' | 'health';
export type ConsentType = 'location' | 'data_share' | 'telemetry';
export interface ConsentRecord {
  userId: string;
  consentType: ConsentType;
  granted: boolean;
  timestamp: number;
  revokedAt?: number;
}
export const AccessMatrix: Record<DataClass, string[]> = {
  public: ['user', 'admin', 'service'],
  internal: ['admin', 'service'],
  sensitive: ['admin'],
  health: ['admin', 'compliance'],
};
