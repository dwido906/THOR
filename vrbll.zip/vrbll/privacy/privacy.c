// privacy.c
// Minimal privacy and consent management implementation for VRBLL (C)
#include "privacy_api.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define PRIVACY_FILE_PREFIX "vrbll_privacy_"
#define CONSENT_LOG_FILE "vrbll_consent.log"

int privacy_init(void) {
    // No-op for demo
    return 0;
}

int privacy_set_setting(const char* user, const char* setting, const char* value) {
    char filename[256];
    snprintf(filename, sizeof(filename), "%s%s.txt", PRIVACY_FILE_PREFIX, user);
    FILE* f = fopen(filename, "a");
    if (!f) return -1;
    fprintf(f, "%s=%s\n", setting, value);
    fclose(f);
    return 0;
}

int privacy_get_setting(const char* user, const char* setting, char* value, size_t bufsize) {
    char filename[256];
    snprintf(filename, sizeof(filename), "%s%s.txt", PRIVACY_FILE_PREFIX, user);
    FILE* f = fopen(filename, "r");
    if (!f) return -1;
    char line[256];
    while (fgets(line, sizeof(line), f)) {
        char key[128], val[128];
        if (sscanf(line, "%127[^=]=%127[^\n]", key, val) == 2) {
            if (strcmp(key, setting) == 0) {
                strncpy(value, val, bufsize-1);
                value[bufsize-1] = '\0';
                fclose(f);
                return 0;
            }
        }
    }
    fclose(f);
    return -1;
}

int privacy_log_consent(const char* user, const char* event) {
    FILE* f = fopen(CONSENT_LOG_FILE, "a");
    if (!f) return -1;
    fprintf(f, "%s: %s\n", user, event);
    fclose(f);
    return 0;
}
