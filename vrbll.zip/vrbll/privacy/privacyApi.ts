// privacyApi.ts
// TypeScript API for privacy and consent management in VRBLL

import * as store from './privacyStore';

export function initPrivacy(): Promise<void> {
  return store.initPrivacy();
}

export function setPrivacySetting(user: string, setting: string, value: string): Promise<void> {
  return store.setPrivacySetting(user, setting, value);
}

export function getPrivacySetting(user: string, setting: string): Promise<string> {
  return store.getPrivacySetting(user, setting);
}

export function logConsent(user: string, event: string): Promise<void> {
  return store.logConsent(user, event);
}
