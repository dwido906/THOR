// Audit log for consent and data access
import fs from 'fs';
const LOG_FILE = __dirname + '/privacy_audit.log';
export function auditConsent(action: string, record: any) {
  fs.appendFileSync(LOG_FILE, JSON.stringify({ action, record, ts: Date.now() }) + '\n');
}
export function auditDataAccess(userId: string, dataClass: string, action: string) {
  fs.appendFileSync(LOG_FILE, JSON.stringify({ userId, dataClass, action, ts: Date.now() }) + '\n');
}
