// Privacy compliance rules (GDPR, CCPA, HIPAA)
export const ComplianceRules = {
  GDPR: {
    requireConsent: true,
    rightToBeForgotten: true,
    dataPortability: true,
  },
  CCPA: {
    requireOptOut: true,
    doNotSell: true,
  },
  HIPAA: {
    restrictHealthData: true,
    auditRequired: true,
  },
};
