// privacyStore.ts
// Minimal privacy and consent management implementation for VRBLL (TypeScript)
import * as fs from 'fs';

const DB_FILE = 'vrbll_privacy.json';
const CONSENT_LOG_FILE = 'vrbll_consent.log';

let privacy: Record<string, Record<string, string>> = {};

function loadPrivacy() {
  if (fs.existsSync(DB_FILE)) {
    privacy = JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
  } else {
    privacy = {};
  }
}

function savePrivacy() {
  fs.writeFileSync(DB_FILE, JSON.stringify(privacy, null, 2));
}

export async function initPrivacy() {
  loadPrivacy();
}

export async function setPrivacySetting(user: string, setting: string, value: string) {
  if (!privacy[user]) privacy[user] = {};
  privacy[user][setting] = value;
  savePrivacy();
}

export async function getPrivacySetting(user: string, setting: string): Promise<string> {
  loadPrivacy();
  return (privacy[user] && privacy[user][setting]) ? privacy[user][setting] : '';
}

export async function logConsent(user: string, event: string) {
  fs.appendFileSync(CONSENT_LOG_FILE, `${user}: ${event}\n`);
}
