// privacy_api.h
// Privacy and consent management API for VRBLL (C)
#ifndef PRIVACY_API_H
#define PRIVACY_API_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// Initialize privacy module
int privacy_init(void);

// Set user privacy setting
int privacy_set_setting(const char* user, const char* setting, const char* value);

// Get user privacy setting
int privacy_get_setting(const char* user, const char* setting, char* value, size_t bufsize);

// Log consent event
int privacy_log_consent(const char* user, const char* event);

#ifdef __cplusplus
}
#endif

#endif // PRIVACY_API_H
