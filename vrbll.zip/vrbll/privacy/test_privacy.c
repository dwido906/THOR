// test_privacy.c
// Test stub for VRBLL privacy C API
#include "privacy_api.h"
#include <stdio.h>

int main() {
    privacy_init();
    privacy_set_setting("alice", "share_profile", "no");
    char value[64];
    privacy_get_setting("alice", "share_profile", value, sizeof(value));
    privacy_log_consent("alice", "accepted_terms");
    printf("Privacy tests ran (stub)\n");
    return 0;
}
