import request from 'supertest';
import express from 'express';
import consentApi from './consentApi';

describe('Consent API', () => {
  const app = express();
  app.use(express.json());
  app.use('/privacy', consentApi);
  it('grants and revokes consent', async () => {
    const userId = 'u1';
    const type = 'location';
    let res = await request(app).post('/privacy/consent/grant').send({ userId, consentType: type });
    expect(res.body.success).toBe(true);
    res = await request(app).post('/privacy/consent/revoke').send({ userId, consentType: type });
    expect(res.body.success).toBe(true);
  });
  it('lists consents', async () => {
    const userId = 'u2';
    await request(app).post('/privacy/consent/grant').send({ userId, consentType: 'telemetry' });
    const res = await request(app).get(`/privacy/consent/list/${userId}`);
    expect(Array.isArray(res.body)).toBe(true);
  });
});
