# VRBLL Protocol Bridges

This module provides protocol bridges for interoperability with Discord, Matrix, IRC, and other platforms. It is modular, secure, and testable.

## Features
- Bridges to Discord, Matrix, IRC, and more
- Message and presence sync
- Modular, containerized, and testable

## Integration
- C and TypeScript APIs for VRBLL core and UI
- Works with Akira mesh and GateScore authentication

## Development
- See `protocolbridge_api.h` and `protocolbridgeApi.ts` for API details
- Run `test_protocolbridge.c` and `test_protocolbridgeApi.ts` for test stubs

---
