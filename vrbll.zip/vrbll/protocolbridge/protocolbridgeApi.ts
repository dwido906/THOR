// protocolbridgeApi.ts
// TypeScript API for protocol bridges in VRBLL

import * as store from './protocolbridgeStore';

export function initProtocolBridge(): Promise<void> {
  return store.initProtocolBridge();
}

export function connectPlatform(platform: string, credentials: string): Promise<void> {
  return store.connectPlatform(platform, credentials);
}

export function syncMessage(platform: string, message: string): Promise<void> {
  return store.syncMessage(platform, message);
}

export function disconnectPlatform(platform: string): Promise<void> {
  return store.disconnectPlatform(platform);
}
