// protocolbridge_api.h
// Protocol bridge API for VRBLL (C)
#ifndef PROTOCOLBRIDGE_API_H
#define PROTOCOLBRIDGE_API_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// Initialize protocol bridge
int protocolbridge_init(void);

// Connect to external platform
int protocolbridge_connect(const char* platform, const char* credentials);

// Sync message to platform
int protocolbridge_sync_message(const char* platform, const char* message);

// Disconnect from platform
int protocolbridge_disconnect(const char* platform);

#ifdef __cplusplus
}
#endif

#endif // PROTOCOLBRIDGE_API_H
