// test_protocolbridge.c
// Test stub for VRBLL protocol bridge C API
#include "protocolbridge_api.h"
#include <stdio.h>

int main() {
    protocolbridge_init();
    protocolbridge_connect("discord", "token");
    protocolbridge_sync_message("discord", "Hello from VRBLL");
    protocolbridge_disconnect("discord");
    printf("Protocol bridge tests ran (stub)\n");
    return 0;
}
