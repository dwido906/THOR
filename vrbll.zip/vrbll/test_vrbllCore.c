#include <assert.h>
int vrbll_init();
int main() {
    assert(vrbll_init() == 0);
    return 0;
}
